import { artTemplatesPath } from '../data/packagingServices'

const primaryLinks = [
  ['Home', '/#home'],
  ['Packaging Services', '/packaging-services/packaging-development'],
  ['Industries', '/industries/food-beverage'],
  ['Projects', '/projects/packaging-starts-here'],
  ['About Us', '#about'],
  ['Packaging Times', '#packaging-times'],
  ['Project Review', '/project-review/starting-point'],
]

const secondaryLinks = [
  ['Contact Us', '#contact'],
  ['Bag and Pouch Die Lines / Template Visuals', artTemplatesPath],
  ['Blog', '#blog'],
]

function LinkList({ links }) {
  return (
    <ul className="list-disc marker:text-black">
      {links.map(([label, href]) => (
        <li key={label}>
          <a
            href={href}
            target={href.toLowerCase().endsWith('.pdf') ? '_blank' : undefined}
            rel={href.toLowerCase().endsWith('.pdf') ? 'noreferrer' : undefined}
          >
            {label}
          </a>
        </li>
      ))}
    </ul>
  )
}

function SocialLinks() {
  return (
    <div className="footer__socials" aria-label="Social media links">
      <a className="social-button social-button--x" href="#social-x" aria-label="X">X</a>
      <a className="social-button social-button--facebook" href="#social-facebook" aria-label="Facebook">f</a>
      <a className="social-button social-button--youtube" href="#social-youtube" aria-label="YouTube"><i /></a>
      <a className="social-button social-button--linkedin" href="#social-linkedin" aria-label="LinkedIn">in</a>
    </div>
  )
}

export default function Footer() {
  return (
    <footer className="footer" id="contact">
      <div className="footer__content">
        <address className="footer__contact">
          <span>Mailing Address:</span>
          <strong>P.O. Box 732024<br />Ormond Beach, Florida&nbsp; 32173-2024</strong>
          <span>E-Mail:</span>
          <a href="mailto:info@packagingconsultantsusa.com">info@packagingconsultantsusa.com</a>
        </address>

        <div className="footer__navigation">
          <nav aria-label="Company links"><LinkList links={primaryLinks} /></nav>
          <div className="footer__navigation-secondary">
            <nav aria-label="Resources"><LinkList links={secondaryLinks} /></nav>
          </div>
        </div>

        <div className="footer__brand">
          <SocialLinks />
          <div className="footer__brand-lockup">
            <img src="/assets/site/footer-brand.png" alt="Packaging Consultants USA — America's Leading Packaging Design and Launch Consulting" />
          </div>
        </div>
      </div>

      <div className="footer__legal">
        <span>Signature American Industries LLC</span>
        <i>•</i>
        <span>Packaging Consultants USA</span>
        <span>Copyright Ⓒ 2026</span>
        <span>All Rights Reserved</span>
      </div>
    </footer>
  )
}
