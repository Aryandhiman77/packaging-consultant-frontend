import { useEffect, useMemo, useState } from 'react'
import { Link, Navigate, useParams } from 'react-router-dom'
import ContentWatermark from './ContentWatermark'
import Footer from './Footer'
import HeaderHero from './HeaderHero'
import { projectReviewBySlug, projectReviewSteps } from '../data/projectReview'

const storageKey = 'packaging-consultants-project-review'

function scrollPageTop() {
  const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  window.scrollTo({ top: 0, left: 0, behavior: reduceMotion ? 'auto' : 'smooth' })
}

function fieldKey(step, group, label) {
  return `${step.slug}:${group.name || group.heading}:${label}`
}

function ChoiceGroup({ step, group, values, updateValue }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {group.options.map((option) => {
        const key = fieldKey(step, group, option)
        const checked = group.type === 'radio' ? values[group.name] === option : Boolean(values[key])
        return (
          <label key={option} className={`flex cursor-pointer items-start gap-3 border p-3.5 text-sm font-bold transition sm:rounded-xl ${checked ? 'border-[#e51f32] bg-[#fff1f2] text-[#8f1321]' : 'border-[#ded4cd] bg-white/85 text-[#49372d] hover:border-[#c8b7ad]'}`}>
            <input
              type={group.type}
              name={group.name}
              checked={checked}
              onChange={(event) => updateValue(group.type === 'radio' ? group.name : key, group.type === 'radio' ? option : event.target.checked)}
              className="mt-0.5 h-4 w-4 accent-[#e51f32]"
            />
            <span>{option}</span>
          </label>
        )
      })}
    </div>
  )
}

function TextFields({ step, group, values, updateValue }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {group.fields.map((label, index) => {
        const key = fieldKey(step, group, label)
        const isLong = !['Name', 'Email', 'City and State', 'Preferred contact method', 'Best time to contact'].includes(label) && (label.length > 42 || index === group.fields.length - 1)
        return (
          <label key={label} className={isLong ? 'sm:col-span-2' : ''}>
            <span className="mb-2 block text-xs font-black tracking-wide text-[#6e5547] uppercase">{label}</span>
            {isLong ? (
              <textarea value={values[key] || ''} onChange={(event) => updateValue(key, event.target.value)} rows="3" className="w-full border border-[#d7ccc4] bg-white/90 px-4 py-3 text-sm outline-none transition focus:border-[#e51f32] focus:ring-2 focus:ring-[#e51f32]/15 sm:rounded-xl" />
            ) : (
              <input type={label === 'Email' ? 'email' : 'text'} value={values[key] || ''} onChange={(event) => updateValue(key, event.target.value)} className="h-12 w-full border border-[#d7ccc4] bg-white/90 px-4 text-sm outline-none transition focus:border-[#e51f32] focus:ring-2 focus:ring-[#e51f32]/15 sm:rounded-xl" />
            )}
          </label>
        )
      })}
    </div>
  )
}

function ReviewGroup({ step, group, values, updateValue }) {
  return (
    <section className="mt-6 border border-[#e2d8d0] bg-[#faf8f6]/90 p-5 sm:rounded-2xl sm:p-7">
      <h2 className="mb-4 text-lg font-black text-[#2b201a]">{group.heading}</h2>
      {(group.type === 'radio' || group.type === 'checkbox') && <ChoiceGroup step={step} group={group} values={values} updateValue={updateValue} />}
      {(group.type === 'text' || group.type === 'contact') && <TextFields step={step} group={group} values={values} updateValue={updateValue} />}
      {group.type === 'file' && (
        <label className="flex min-h-32 cursor-pointer flex-col items-center justify-center border-2 border-dashed border-[#cdbeb4] bg-white/75 px-5 py-6 text-center transition hover:border-[#e51f32] sm:rounded-xl">
          <span className="text-sm font-black text-[#392b23]">Select project files</span>
          <span className="mt-1 text-xs text-[#7b6558]">Photographs, artwork, dielines, specifications, quotations or records</span>
          <input type="file" multiple className="mt-4 block max-w-full text-xs file:mr-3 file:border-0 file:bg-[#e51f32] file:px-4 file:py-2 file:font-bold file:text-white sm:file:rounded-lg" onChange={(event) => updateValue('uploadedFiles', Array.from(event.target.files || []).map((file) => file.name))} />
          {values.uploadedFiles?.length > 0 && <span className="mt-3 text-xs font-bold text-[#765342]">{values.uploadedFiles.join(', ')}</span>}
        </label>
      )}
    </section>
  )
}

function ReviewDetail({ step }) {
  const [values, setValues] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem(storageKey) || '{}') } catch { return {} }
  })
  const [submitted, setSubmitted] = useState(false)
  const stepIndex = projectReviewSteps.findIndex((item) => item.slug === step.slug)
  const previous = projectReviewSteps[stepIndex - 1]
  const next = projectReviewSteps[stepIndex + 1]
  const reference = useMemo(() => `PCR-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`, [submitted])

  useEffect(() => {
    const serializable = { ...values, uploadedFiles: values.uploadedFiles || [] }
    sessionStorage.setItem(storageKey, JSON.stringify(serializable))
  }, [values])

  const updateValue = (key, value) => setValues((current) => ({ ...current, [key]: value }))

  return (
    <main className="relative overflow-x-clip bg-[#f5f1ed] text-[#30231c]">
      <div className="absolute inset-x-0 top-0 h-72 bg-[linear-gradient(120deg,#17110f_0%,#39271f_62%,#7e292c_100%)]" />
      <img className="pointer-events-none absolute top-16 right-[-5rem] w-[31rem] opacity-[.075]" src="/assets/site/header-mark-clean.png" alt="" />

      <div className="relative mx-auto max-w-7xl px-0 py-10 sm:px-8 lg:px-12 lg:py-14">
        <nav className="flex flex-wrap items-center gap-2 px-4 text-xs font-bold text-white/60 sm:px-0" aria-label="Breadcrumb">
          <Link to="/" className="!text-white/75 no-underline hover:!text-white">Home</Link><span>/</span>
          <span className="text-white/75">Project Review</span><span>/</span><span className="text-white">{step.title}</span>
        </nav>

        <div className="mt-7 grid items-start gap-0 sm:gap-7 lg:grid-cols-[minmax(0,1fr)_300px]">
          <article className="relative overflow-hidden border-0 bg-white shadow-[0_28px_80px_rgba(35,20,12,.24)] sm:rounded-[1.75rem] sm:border sm:border-white/30">
            <ContentWatermark repeat />
            <header className="relative z-10 overflow-hidden bg-[linear-gradient(135deg,#fff_0%,#f7f3ef_60%,#eadfd7_100%)] px-6 py-9 sm:px-10 sm:py-12">
              <div className="absolute top-0 left-0 h-1.5 w-full bg-[#e51f32]" />
              <p className="text-xs font-black tracking-[.2em] text-[#d91f31] uppercase">Project Review · Step {stepIndex + 1} of {projectReviewSteps.length}</p>
              <h1 className="mt-3 max-w-4xl font-serif text-3xl leading-tight font-bold tracking-tight text-[#211914] sm:text-5xl">{step.title}</h1>
            </header>

            <form className="relative z-10 px-6 py-8 sm:px-10 sm:py-10" onSubmit={(event) => { event.preventDefault(); setSubmitted(true); scrollPageTop() }}>
              <div className="space-y-4 text-[17px] leading-8 text-[#4b3a30]">{step.intro.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</div>
              {step.groups.map((group) => <ReviewGroup key={group.heading} step={step} group={group} values={values} updateValue={updateValue} />)}
              <div className="mt-7 space-y-4 text-[16px] leading-7 text-[#4b3a30]">{step.body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</div>

              {submitted && (
                <div className="mt-8 border border-[#9ecfa9] bg-[#eef9f0] p-5 text-[#21552c] sm:rounded-2xl">
                  <h2 className="font-black">Thank you. Your Project Review has been received.</h2>
                  <p className="mt-2 text-sm">Reference number: <strong>{reference}</strong>. Your saved responses remain available in this browser session.</p>
                </div>
              )}

              <div className="mt-9 flex flex-wrap items-center justify-between gap-3 border-t border-[#ded2ca] pt-7">
                {previous ? <Link to={`/project-review/${previous.slug}`} onClick={scrollPageTop} className="border border-[#d7c9c0] bg-white px-4 py-3 text-sm font-black !text-[#4b3529] no-underline hover:border-[#e51f32] hover:!text-[#c91929] sm:rounded-xl">← {previous.title}</Link> : <span />}
                {next ? <Link to={`/project-review/${next.slug}`} onClick={scrollPageTop} className="bg-[#e51f32] px-5 py-3 text-sm font-black !text-white no-underline shadow-[0_10px_25px_rgba(229,31,50,.24)] hover:bg-[#c91929] sm:rounded-xl">Continue to {next.title} →</Link> : <button type="submit" className="border-0 bg-[#e51f32] px-5 py-3 text-sm font-black text-white shadow-[0_10px_25px_rgba(229,31,50,.24)] hover:bg-[#c91929] sm:rounded-xl">Submit Project Review</button>}
              </div>
            </form>
          </article>

          <aside className="self-start border-0 bg-[#1f1713]/95 p-4 text-white shadow-[0_20px_50px_rgba(28,17,11,.22)] backdrop-blur sm:rounded-2xl sm:border sm:border-white/20 lg:sticky lg:top-6 lg:max-h-[calc(100vh-3rem)] lg:overflow-y-auto" aria-label="Project Review steps">
            <h2 className="px-3 pt-2 pb-3 text-xs font-black tracking-[.18em] text-[#ef9da6] uppercase">Project Review</h2>
            <nav className="grid gap-1">
              {projectReviewSteps.map((item, index) => (
                <Link key={item.slug} to={`/project-review/${item.slug}`} onClick={scrollPageTop} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold no-underline transition ${item.slug === step.slug ? 'bg-[#e51f32] !text-white' : '!text-white/75 hover:bg-white/10 hover:!text-white'}`}>
                  <span className="text-[10px] text-white/45">{String(index + 1).padStart(2, '0')}</span>{item.title}
                </Link>
              ))}
            </nav>
          </aside>
        </div>
      </div>
    </main>
  )
}

export default function ProjectReviewPage() {
  const { slug } = useParams()
  const step = slug ? projectReviewBySlug[slug] : null
  if (!step) return <Navigate to="/project-review/starting-point" replace />
  return <div className="page-shell"><HeaderHero compact /><ReviewDetail step={step} /><Footer /></div>
}
