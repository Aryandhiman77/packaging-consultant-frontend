import { useEffect } from 'react'
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import AdminLayout from './admin/AdminLayout'
import AdminDashboard from './admin/AdminDashboard'
import NavigationSettings from './admin/NavigationSettings'
import ArtTemplatesPage from './components/ArtTemplatesPage'
import Footer from './components/Footer'
import HeaderHero from './components/HeaderHero'
import IndustryPage from './components/IndustryPage'
import MainContent from './components/MainContent'
import PackagingServicePage from './components/PackagingServicePage'
import ProjectPage from './components/ProjectPage'
import ProjectReviewPage from './components/ProjectReviewPage'

function PublicSite() {
  return (
    <div className="page-shell">
      <HeaderHero />
      <MainContent />
      <Footer />
    </div>
  )
}

function ScrollToTop() {
  const { pathname } = useLocation()

  useEffect(() => {
    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    window.scrollTo({ top: 0, left: 0, behavior: reduceMotion ? 'auto' : 'smooth' })
  }, [pathname])

  return null
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Routes>
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="settings" element={<NavigationSettings />} />
        </Route>
        <Route path="/packaging-services" element={<Navigate to="/" replace />} />
        <Route path="/packaging-services/art-templates" element={<ArtTemplatesPage />} />
        <Route path="/packaging-services/:slug" element={<PackagingServicePage />} />
        <Route path="/industries/:slug" element={<IndustryPage />} />
        <Route path="/projects/:slug" element={<ProjectPage />} />
        <Route path="/project-review/:slug" element={<ProjectReviewPage />} />
        <Route path="*" element={<PublicSite />} />
      </Routes>
    </BrowserRouter>
  )
}
