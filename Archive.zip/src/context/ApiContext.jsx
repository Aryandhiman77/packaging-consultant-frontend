import { createContext, useCallback, useContext, useMemo, useState } from 'react'

const ApiContext = createContext(null)

export function ApiProvider({ children }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const request = useCallback(async (path, options = {}) => {
    setLoading(true)
    setError(null)

    try {
      const baseUrl = (import.meta.env.VITE_API_BASE_URL ?? '').replace(/\/$/, '')
      const response = await fetch(`${baseUrl}${path}`, {
        ...options,
        headers: { 'Content-Type': 'application/json', ...options.headers },
      })

      if (response.status === 204) return null
      const payload = await response.json().catch(() => ({}))
      if (!response.ok) {
        throw new Error(payload.message || `Request failed (${response.status})`)
      }
      return payload
    } catch (requestError) {
      setError(requestError)
      throw requestError
    } finally {
      setLoading(false)
    }
  }, [])

  const getPublicNavigation = useCallback(
    () => request('/api/settings/navigation'),
    [request],
  )
  const getAdminSettings = useCallback(
    () => request('/api/admin/settings/current'),
    [request],
  )
  const saveAdminSettings = useCallback(
    (topNavigation) => request('/api/admin/settings/current', {
      method: 'PUT',
      body: JSON.stringify({ topNavigation }),
    }),
    [request],
  )

  const value = useMemo(() => ({
    request,
    getPublicNavigation,
    getAdminSettings,
    saveAdminSettings,
    loading,
    error,
  }), [request, getPublicNavigation, getAdminSettings, saveAdminSettings, loading, error])
  return <ApiContext.Provider value={value}>{children}</ApiContext.Provider>
}

export function useApi() {
  const context = useContext(ApiContext)
  if (!context) throw new Error('useApi must be used inside ApiProvider')
  return context
}
