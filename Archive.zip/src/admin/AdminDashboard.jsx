import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useApi } from '../context/ApiContext'

export default function AdminDashboard() {
  const { getAdminSettings } = useApi()
  const [summary, setSummary] = useState({ links: '—', dropdownLinks: '—', connected: null })

  useEffect(() => {
    let active = true
    getAdminSettings()
      .then(({ data }) => {
        if (!active) return
        setSummary({
          links: data.topNavigation.length,
          dropdownLinks: data.topNavigation.reduce((total, item) => total + (item.children?.length || 0), 0),
          connected: true,
        })
      })
      .catch(() => active && setSummary((current) => ({ ...current, connected: false })))
    return () => { active = false }
  }, [getAdminSettings])

  return (
    <div>
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <p className="text-sm font-bold text-[#d51f2c]">Overview</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight text-slate-950 dark:text-white">Dashboard</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500 dark:text-slate-400">Manage the public website configuration from one clean workspace.</p>
        </div>
        <Link to="/admin/settings" className="rounded-xl bg-slate-950 px-5 py-3 text-center text-sm font-bold !text-white no-underline shadow-lg shadow-slate-900/10 hover:bg-slate-800 dark:bg-[#e82634] dark:shadow-red-950/30 dark:hover:bg-[#ca1c29]">Manage navigation</Link>
      </div>

      <section className="mt-8 grid gap-4 sm:grid-cols-3" aria-label="Configuration summary">
        {[
          ['Top-level links', summary.links, 'Visible in the main navigation'],
          ['Dropdown links', summary.dropdownLinks, 'Nested navigation destinations'],
          ['API status', summary.connected === null ? 'Checking' : summary.connected ? 'Connected' : 'Offline', summary.connected === false ? 'Start the backend and MongoDB' : 'Settings service availability'],
        ].map(([label, value, detail]) => (
          <article key={label} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_8px_30px_rgba(15,23,42,.04)] transition-colors dark:border-white/[.08] dark:bg-[#111a27] dark:shadow-[0_14px_40px_rgba(0,0,0,.18)]">
            <p className="text-xs font-bold tracking-[.12em] text-slate-400 uppercase dark:text-slate-500">{label}</p>
            <p className="mt-3 text-3xl font-bold text-slate-950 dark:text-white">{value}</p>
            <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">{detail}</p>
          </article>
        ))}
      </section>

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-[0_8px_30px_rgba(15,23,42,.04)] transition-colors dark:border-white/[.08] dark:bg-[#111a27] dark:shadow-[0_14px_40px_rgba(0,0,0,.18)]">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-50 text-lg text-emerald-600">✓</span>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Admin foundation is ready</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Navigation settings are editable now. Authentication will be added in the final phase.</p>
          </div>
        </div>
      </section>
    </div>
  )
}
